<div class="row">
    <div class="col-md-12">
        <iframe src="<?= base_url('file/'.$perusahaan['bukti_kerjasama'])?>" height="1000px" width="100%" title="Iframe Example"></iframe>
    </div>
</div>
mna view nya